package com.example.weatherapplication.data.repository

import com.example.weatherapplication.data.model.ForecastResponse
import com.example.weatherapplication.data.model.WeatherResponse
import retrofit2.Response
import javax.inject.Inject

class WeatherRepositoryImpl @Inject constructor(
    private val api: Api
): WeatherRepository {
    override suspend fun getWeatherData(lat: Double, lon: Double) : Response<WeatherResponse> {
        return api.getWeatherData(lat, lon, "metric", "517066dd61feb8345fb5a16ff218a283")
    }

    override suspend fun getWeatherByCity(cityName: String): Response<WeatherResponse> {
        return api.getWeatherByCity(cityName, "metric", "517066dd61feb8345fb5a16ff218a283")
    }

    override suspend fun getForecastData(
        lat: Double,
        lon: Double
    ): Response<ForecastResponse> {
        return api.getForecastData(lat, lon, "metric", "517066dd61feb8345fb5a16ff218a283")
    }
}
