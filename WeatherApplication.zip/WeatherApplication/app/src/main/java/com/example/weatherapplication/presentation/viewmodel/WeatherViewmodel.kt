package com.example.weatherapplication.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapplication.data.model.ForecastResponse
import com.example.weatherapplication.data.model.Resource
import com.example.weatherapplication.data.model.WeatherResponse
import com.example.weatherapplication.data.repository.WeatherRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WeatherViewmodel @Inject constructor(
    private val repository: WeatherRepository
) : ViewModel(){

    private val _weatherState = MutableStateFlow<Resource<WeatherResponse>>(Resource.Loading())
    val weatherState: StateFlow<Resource<WeatherResponse>> = _weatherState.asStateFlow()

    private val _forecastState = MutableStateFlow<Resource<ForecastResponse>>(Resource.Loading())
    val forecastState: StateFlow<Resource<ForecastResponse>> = _forecastState.asStateFlow()


    private val _recentSearches = MutableStateFlow<List<String>>(emptyList())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    init {
        // Fetch weather for London by default
        getWeatherData(51.5074, -0.1278)
        getForecastData(51.5074, -0.1278)
    }

    fun getWeatherData(lat: Double, lon: Double) {
        viewModelScope.launch {
            _weatherState.value = Resource.Loading()
            try {
                val response = repository.getWeatherData(lat, lon)
                if (response.isSuccessful && response.body() != null) {
                    _weatherState.value = Resource.Success(response.body()!!)
                } else {
                    _weatherState.value = Resource.Error(response.message() ?: "Unknown error")
                }
                getForecastData(lat, lon)
            } catch (e: Exception) {
                _weatherState.value = Resource.Error(e.localizedMessage ?: "Network error")
            }
        }
    }

    fun getWeatherByCity(cityName: String) {
        viewModelScope.launch {
            _weatherState.value = Resource.Loading()
            try {
                val response = repository.getWeatherByCity(cityName)
                if (response.isSuccessful && response.body() != null) {
                    _weatherState.value = Resource.Success(response.body()!!)
                    val coord = response.body()?.coord
                    if (coord != null) {
                        getForecastData(coord.lat, coord.lon)
                    }
                    val currentList = _recentSearches.value.toMutableList()
                    if (!currentList.any { it.equals(cityName, ignoreCase = true) }) {
                        currentList.add(0, cityName)
                        _recentSearches.value = currentList
                    }
                } else {
                    _weatherState.value = Resource.Error(response.message() ?: "City not found")
                }
            } catch (e: Exception) {
                _weatherState.value = Resource.Error(e.localizedMessage ?: "Network error")
            }
        }
    }
    fun getForecastData(lat: Double, lon: Double) {
        viewModelScope.launch {
            _forecastState.value = Resource.Loading()
            try {
                val response = repository.getForecastData(lat, lon)
                if (response.isSuccessful && response.body() != null) {
                    _forecastState.value = Resource.Success(response.body()!!)
                } else {
                    _forecastState.value = Resource.Error(response.message() ?: "Unknown error")
                }
            } catch (e: Exception) {
                _forecastState.value = Resource.Error(e.localizedMessage ?: "Network error")
            }
        }
    }
}
