package com.example.weatherapplication.presentation

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.weatherapplication.R
import com.example.weatherapplication.data.model.Resource
import com.example.weatherapplication.presentation.viewmodel.WeatherViewmodel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HomeScreen(
    viewModel: WeatherViewmodel = hiltViewModel(),
    onOpenSearch: () -> Unit = {}
) {
    val weatherResource by viewModel.weatherState.collectAsState()
    val forecastResource by viewModel.forecastState.collectAsState()

    val weatherState = weatherResource.data
    val forecastState = forecastResource.data

    val weatherCondition = weatherState?.weather?.firstOrNull()?.main ?: "Clear"
    val backgroundRes = when (weatherCondition.lowercase()) {
        "clear" -> R.drawable.sunny_bg
        "rain", "drizzle", "thunderstorm" -> R.drawable.rainy_bg
        "clouds" -> R.drawable.cloudy_bg
        "snow" -> R.drawable.snow_bg
        "haze", "mist", "fog" -> R.drawable.haze_bg
        else -> R.drawable.sunny_bg
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = backgroundRes),
                contentDescription = "Background",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        }

        // Main screen column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(15.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Location Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Location",
                    tint = Color.White,
                    modifier = Modifier.padding(end = 5.dp)
                )
                Text(
                    text = weatherState?.name ?: "Weather App",
                    color = Color.White,
                    fontFamily = FontFamily(Font(R.font.roboto_regular)),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    painter = painterResource(id = R.drawable.ic_plus),
                    contentDescription = "Search City",
                    tint = Color.White,
                    modifier = Modifier
                        .size(30.dp)
                        .padding(end = 5.dp)
                        .clickable { onOpenSearch() }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            when {
                weatherResource is Resource.Loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color.White
                        )
                    }
                }
                weatherResource is Resource.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = weatherResource.message ?: "Failed to load weather data",
                            color = Color.White,
                            fontFamily = FontFamily(Font(R.font.roboto_medium)),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                weatherResource is Resource.Success -> {
                    // Success state content
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Weather text column centered on screen
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = weatherState?.weather?.firstOrNull()?.main ?: "Clear",
                                color = Color.White,
                                fontFamily = FontFamily(Font(R.font.roboto_bold)),
                                style = MaterialTheme.typography.headlineLarge
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = weatherState?.main?.temp?.let { "${it.toInt()}°C" } ?: "--°C",
                                color = Color.White,
                                fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                style = MaterialTheme.typography.displayLarge
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_humidity),
                                    contentDescription = "Humidity",
                                    tint = Color.White,
                                    modifier = Modifier.padding(end = 5.dp)
                                )
                                Text(
                                    text = "HUMIDITY",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = weatherState?.main?.humidity?.let { "$it%" } ?: "--%",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_wind),
                                    contentDescription = "wind",
                                    tint = Color.White,
                                    modifier = Modifier.padding(end = 5.dp)
                                )
                                Text(
                                    text = "WIND",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = weatherState?.wind?.speed?.let { "$it m/s" } ?: "-- m/s",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_feels_like),
                                    contentDescription = "feels",
                                    tint = Color.White,
                                    modifier = Modifier.padding(end = 5.dp)
                                )
                                Text(
                                    text = "FEELS LIKE",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = weatherState?.main?.feelsLike?.let { "${it.toInt()}°C" } ?: "--°C",
                                    color = Color.White,
                                    fontFamily = FontFamily(Font(R.font.roboto_medium)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }

                        val hourlyItems = remember(forecastState) {
                            val list = forecastState?.list ?: emptyList()
                            if (list.isNotEmpty()) {
                                list.take(4).map { item ->
                                    val time = formatHour(item.dtTxt)
                                    val condition = item.weather.firstOrNull()?.main ?: "Clear"
                                    val icon = getWeatherIcon(condition)
                                    val temp = "${item.main.temp.toInt()}°"
                                    HourlyItemData(time, icon, temp)
                                }
                            } else {
                                listOf(
                                    HourlyItemData("3 PM", R.drawable.ic_rainy, "24°"),
                                    HourlyItemData("6 PM", R.drawable.ic_rainy, "23°"),
                                    HourlyItemData("9 PM", R.drawable.ic_cloudy, "21°"),
                                    HourlyItemData("12 AM", R.drawable.ic_sunny, "20°")
                                )
                            }
                        }

                        val dailyItems = remember(forecastState) {
                            val list = forecastState?.list ?: emptyList()
                            if (list.isNotEmpty()) {
                                val groupedByDate = list.groupBy {
                                    it.dtTxt?.split(" ")?.getOrElse(0) { "" } ?: ""
                                }
                                groupedByDate.entries.take(5).mapIndexed { index, entry ->
                                    val date = entry.key
                                    val items = entry.value
                                    val dayName = formatDayName(date, index)
                                    val condition = items.firstOrNull()?.weather?.firstOrNull()?.main ?: "Clear"
                                    val icon = getWeatherIcon(condition)
                                    val maxPop = items.maxOfOrNull { it.pop } ?: 0.0
                                    val popPercent = "${(maxPop * 100).toInt()}%"
                                    val minTemp = "${items.minOfOrNull { it.main.tempMin }?.toInt() ?: 0}°"
                                    val maxTemp = "${items.maxOfOrNull { it.main.tempMax }?.toInt() ?: 0}°"
                                    DailyForecastData(dayName, condition, icon, popPercent, minTemp, maxTemp)
                                }
                            } else {
                                emptyList()
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        HourlyForecastSection(hourlyItems)

                        Spacer(Modifier.height(16.dp))
                        DailyForecastSection(dailyItems)

                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }
    }
}

data class HourlyItemData(
    val time: String,
    val icon: Int,
    val temp: String
)

data class DailyForecastData(
    val day: String,
    val condition: String,
    val icon: Int,
    val pop: String,
    val minTemp: String,
    val maxTemp: String
)

@Composable
fun DailyForecastSection(forecastItems: List<DailyForecastData>) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Daily forecast",
                color = Color.White,
                fontFamily = FontFamily(Font(R.font.roboto_bold)),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            forecastItems.forEach { item ->
                DailyForecastRow(item)
                if (item != forecastItems.last()) {
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
fun DailyForecastRow(data: DailyForecastData) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.width(110.dp)
        ) {
            Text(
                text = data.day,
                color = Color.White,
                fontFamily = FontFamily(Font(R.font.roboto_medium)),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = data.condition,
                color = Color.White.copy(alpha = 0.7f),
                fontFamily = FontFamily(Font(R.font.roboto_regular)),
                style = MaterialTheme.typography.bodySmall
            )
        }

        Image(
            painter = painterResource(id = data.icon),
            contentDescription = data.condition,
            modifier = Modifier.size(32.dp)
        )

        Text(
            text = data.pop,
            color = Color(0xFF4FC3F7),
            fontFamily = FontFamily(Font(R.font.roboto_medium)),
            style = MaterialTheme.typography.bodyMedium
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = data.minTemp,
                color = Color.White.copy(alpha = 0.6f),
                fontFamily = FontFamily(Font(R.font.roboto_regular)),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = data.maxTemp,
                color = Color.White,
                fontFamily = FontFamily(Font(R.font.roboto_bold)),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun HourlyForecastSection(hourlyItems: List<HourlyItemData>) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Next 24 hours",
                color = Color.White,
                fontFamily = FontFamily(Font(R.font.roboto_bold)),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                hourlyItems.forEach { item ->
                    HourlyItem(time = item.time, icon = item.icon, temp = item.temp)
                }
            }
        }
    }
}

@Composable
fun HourlyItem(time: String, icon: Int, temp: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = time,
            color = Color.White.copy(alpha = 0.8f),
            fontFamily = FontFamily(Font(R.font.roboto_regular)),
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(10.dp))
        Image(
            painter = painterResource(id = icon),
            contentDescription = time,
            modifier = Modifier.size(32.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = temp,
            color = Color.White,
            fontFamily = FontFamily(Font(R.font.roboto_bold)),
            style = MaterialTheme.typography.titleMedium
        )
    }
}

// Helpers
fun formatHour(dtTxt: String?): String {
    if (dtTxt.isNullOrBlank()) return ""
    return try {
        val timePart = dtTxt.split(" ").getOrNull(1) ?: return dtTxt
        val hourStr = timePart.split(":").getOrNull(0) ?: return timePart
        val hour = hourStr.toInt()
        when {
            hour == 0 -> "12 AM"
            hour < 12 -> "$hour AM"
            hour == 12 -> "12 PM"
            else -> "${hour - 12} PM"
        }
    } catch (e: Exception) {
        dtTxt
    }
}

fun formatDayName(dateStr: String?, index: Int): String {
    if (index == 0) return "Today"
    if (index == 1) return "Tomorrow"
    if (dateStr.isNullOrBlank()) return ""
    return try {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = formatter.parse(dateStr)
        val cal = Calendar.getInstance()
        if (date != null) {
            cal.time = date
            when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SUNDAY -> "Sunday"
                Calendar.MONDAY -> "Monday"
                Calendar.TUESDAY -> "Tuesday"
                Calendar.WEDNESDAY -> "Wednesday"
                Calendar.THURSDAY -> "Thursday"
                Calendar.FRIDAY -> "Friday"
                Calendar.SATURDAY -> "Saturday"
                else -> dateStr
            }
        } else {
            dateStr
        }
    } catch (e: Exception) {
        dateStr
    }
}

fun getWeatherIcon(condition: String): Int {
    return when (condition.lowercase()) {
        "rain", "drizzle" -> R.drawable.ic_rainy
        "thunderstorm" -> R.drawable.ic_storm
        "clouds" -> R.drawable.ic_cloudy
        "clear" -> R.drawable.ic_sunny
        else -> R.drawable.ic_sunny
    }
}
