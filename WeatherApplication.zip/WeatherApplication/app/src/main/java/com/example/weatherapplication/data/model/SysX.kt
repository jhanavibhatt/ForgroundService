package com.example.weatherapplication.data.model


import com.google.gson.annotations.SerializedName

data class SysX(
    @SerializedName("pod")
    val pod: String
)