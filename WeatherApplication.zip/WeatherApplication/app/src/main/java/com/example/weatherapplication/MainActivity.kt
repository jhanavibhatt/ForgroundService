package com.example.weatherapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.weatherapplication.presentation.HomeScreen
import com.example.weatherapplication.presentation.SearchScreen
import com.example.weatherapplication.presentation.viewmodel.WeatherViewmodel
import com.example.weatherapplication.ui.theme.WeatherApplicationTheme
import dagger.hilt.android.AndroidEntryPoint

sealed class Screen {
    object Home : Screen()
    object Search : Screen()
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WeatherApplicationTheme {
                val viewModel: WeatherViewmodel = hiltViewModel()
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

                when (currentScreen) {
                    is Screen.Home -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenSearch = { currentScreen = Screen.Search }
                        )
                    }
                    is Screen.Search -> {
                        SearchScreen(
                            viewModel = viewModel,
                            onCitySelected = { city ->
                                currentScreen = Screen.Home
                            },
                            onBack = {
                                currentScreen = Screen.Home
                            }
                        )
                    }
                }
            }
        }
    }
}
