package com.example.weatherapplication.data.repository

import com.example.weatherapplication.data.model.ForecastResponse
import com.example.weatherapplication.data.model.WeatherResponse
import retrofit2.Response

interface WeatherRepository {
    suspend fun getWeatherData(lat: Double, lon: Double): Response<WeatherResponse>
    suspend fun getWeatherByCity(cityName: String): Response<WeatherResponse>
    suspend fun getForecastData(lat: Double, lon: Double): Response<ForecastResponse>
}
