package com.example.weatherapplication.data.model


import com.google.gson.annotations.SerializedName

data class Item0(
    @SerializedName("clouds")
    val clouds: Clouds,
    @SerializedName("dt")
    val dt: Int,
    @SerializedName("dt_txt")
    val dtTxt: String?,
    @SerializedName("main")
    val main: MainX,
    @SerializedName("pop")
    val pop: Double,
    @SerializedName("rain")
    val rain: Rain?,
    @SerializedName("sys")
    val sys: SysX,
    @SerializedName("visibility")
    val visibility: Int,
    @SerializedName("weather")
    val weather: List<Weather>,
    @SerializedName("wind")
    val wind: Wind
)